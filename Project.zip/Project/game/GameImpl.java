package game;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;

public class GameImpl implements Game{

    private int size;

    private Grid grid;

    private PieceColour player;

    public GameImpl(int size) {
        if (size<=0){
            throw new IllegalArgumentException("Illegal size");
        }
        this.size = size;
        this.grid = new GridImpl(size);
        //initialize the current player to white since white player always starts first
        this.player = PieceColour.WHITE;
    }

    @Override
    public boolean isOver() {

        //check if black has won
        if (blackWon()){
            return true;
        //check if white has won
        } else if (whiteWon()) {
            return true;
        }

        //check if is a draw
        return draw();
    }

    @Override
    public PieceColour winner() {
        if (blackWon()){
            return PieceColour.BLACK;
        } else if (whiteWon()) {
            return PieceColour.WHITE;
        }

        //return None colour if not over or is a draw
        return PieceColour.NONE;
    }

    @Override
    public PieceColour currentPlayer() {
        return this.player;
    }

    @Override
    public Collection<Move> getMoves() {
        Collection<Move> moves = new ArrayList<>();
        for (int i = 0; i < size; i++){
            for (int j = 0; j < size; j++){
                //if colour is None, means it is not occupied and treat it as valid grid
                if (grid.getPiece(i,j).equals(PieceColour.NONE)){
                    moves.add(new MoveImpl(i,j));
                }
            }
        }
        return moves;
    }

    @Override
    public void makeMove(Move move) {
        int row = move.getRow();
        int col = move.getCol();

        //check if move is invalid
        if (!grid.getPiece(row,col).equals(PieceColour.NONE) || row < 0 ||row >= size || col < 0 || col >= size){
            throw new IllegalArgumentException("Move is invalid");
        }

        //sets the colour piece
        grid.setPiece(row,col,this.currentPlayer());

        //alternate the colour of current player
        if (this.currentPlayer().equals(PieceColour.WHITE)){
            this.player = PieceColour.BLACK;
        }else {
            this.player = PieceColour.WHITE;
        }
    }

    @Override
    public Grid getGrid() {
        return grid.copy();
    }

    @Override
    public Game copy() {
        GameImpl copyGame = new GameImpl(size);

        //For deep copy purpose
        copyGame.grid = this.getGrid();
        copyGame.player = this.currentPlayer();
        return copyGame;
    }

    /**
     * Checks if the black player has won
     * @return black player won the game
     */
    public boolean blackWon(){
        boolean blackTopBtn = PathFinder.topToBottom(grid,PieceColour.BLACK);
        boolean blackLftRht = PathFinder.leftToRight(grid,PieceColour.BLACK);
        return blackLftRht||blackTopBtn;
    }

    /**
     * Checks if the white player has won
     * @return white player won the game
     */
    public boolean whiteWon(){
        boolean whiteTopBtn = PathFinder.topToBottom(grid,PieceColour.WHITE);
        boolean whiteLftRht = PathFinder.leftToRight(grid,PieceColour.WHITE);
        return whiteLftRht || whiteTopBtn;
    }

    /**
     * Check if the game is a draw
     * @return The game is a draw
     */
    public boolean draw(){
        for (int i = 0; i < size; i++){
            for (int j = 0; j < size; j++){
                if (grid.getPiece(i,j).equals(PieceColour.NONE)){
                    return false;
                }
            }
        }
        return true;
    }
}