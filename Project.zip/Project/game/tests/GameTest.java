package game.tests;

import java.util.ArrayList;
import java.util.Collection;
import game.*;

public class GameTest extends Test {
    public static void main(String[] args) {
        boolean caught = false;
        try {
            new GameImpl(0);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        expect(true, caught);

        caught = false;
        try {
            new GameImpl(5);
        } catch (IllegalArgumentException e) {
            caught = true;
        }
        expect(false, caught);

        System.out.println("\nBelow is self-writing test:\n\n");

        // TODO: Complete this test


        //Check initial game state
        Game game1 = new GameImpl(4);
        expect(false,game1.isOver());
        expect(PieceColour.NONE,game1.winner());
        expect(PieceColour.WHITE,game1.currentPlayer());
        expect(16,game1.getMoves().size());

        //expect valid white first
        game1.makeMove(new MoveImpl(0,0));
        expect(PieceColour.WHITE,game1.getGrid().getPiece(0,0));
        expect(PieceColour.BLACK,game1.currentPlayer());

        //expect invalid black
        caught = false;
        try {
            game1.makeMove(new MoveImpl(0,0));
        } catch (IllegalArgumentException e){
            caught = true;
        }
        expect(true,caught);

        //test invalid move(out of bounds)
        caught = false;
        try{
            game1.makeMove(new MoveImpl(4,5));
        }catch (IllegalArgumentException e){
            caught = true;
        }
        expect(true, caught);

        caught = false;
        try{
            game1.makeMove(new MoveImpl(-1,4));
        }catch (IllegalArgumentException e){
            caught = true;
        }
        expect(true, caught);

        //still black player since it is an invalid move
        expect(PieceColour.BLACK,game1.currentPlayer());

        //now valid move for black
        game1.makeMove(new MoveImpl(0,1));
        //test for game size
        expect(game1.getGrid().getSize(),4);

        for (int i = 0 ; i < 4; i++){
            for (int j = 0 ; j < 4; j++){
                if (i == 0 && j ==0){
                    expect(PieceColour.WHITE,game1.getGrid().getPiece(0,0));
                } else if (i ==0 && j ==1) {
                    expect(PieceColour.BLACK, game1.getGrid().getPiece(0,1));
                }else {
                    expect(PieceColour.NONE, game1.getGrid().getPiece(i,j));
                }
            }
        }
        Collection<Move> moves = game1.getMoves();
        expect(14, moves.size());


        //TODO: test below
        System.out.println("\nBelow test Copy method and winning:\n\n");

        game1.makeMove(new MoveImpl(1,0));

        expect(PieceColour.BLACK,game1.currentPlayer());
        game1.makeMove(new MoveImpl(1,1));
        //copy the game
        Game game2 = game1.copy();

        game1.makeMove(new MoveImpl(2,0));
        game1.makeMove(new MoveImpl(1,2));

        game1.makeMove(new MoveImpl(3,0));
        //white player wins
        expect(true,game1.isOver());
        expect(PieceColour.WHITE,game1.winner());

        //starts from game2 to test if it is deep copied
        //expect invalid black
        caught = false;
        try {
            game2.makeMove(new MoveImpl(0,0));
        } catch (IllegalArgumentException e){
            caught = true;
        }
        expect(true,caught);

        expect(PieceColour.BLACK, game2.getGrid().getPiece(1,1));
        expect(PieceColour.WHITE,game2.currentPlayer());

        //able to move on copied game
        game2.makeMove(new MoveImpl(1,2));
        expect(PieceColour.WHITE, game2.getGrid().getPiece(1,2));


        //test for draw
        System.out.println("\n Below are test for new game:\n\n");
        Game game = new GameImpl(2);
        game.makeMove(new MoveImpl(0,0));
        game.makeMove(new MoveImpl(0,1));
        game.makeMove(new MoveImpl(1,1));
        game.makeMove(new MoveImpl(1,0));
        expect(PieceColour.NONE,game.winner());
        expect(true,game.isOver());
        expect(0,game.getMoves().size());


        checkAllTestsPassed();
    }
}
