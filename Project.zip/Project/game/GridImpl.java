package game;

import java.util.ArrayList;
import java.util.List;

import static game.PieceColour.*;

public class GridImpl implements Grid{

    private int size;

    private PieceColour[][] grid;

    public GridImpl(int size) {
        this.size = size;

        //grid initialization, this is a PieceColour type grid
        grid = new PieceColour[size][size];
        for (int i = 0 ; i < size;i++){
            for (int j = 0 ; j < size;j++){
                grid[i][j] = NONE;
            }
        }
    }

    @Override
    public int getSize() {
        return this.size;
    }

    @Override
    public PieceColour getPiece(int row, int col) {
        checkValid(row,col);
        return grid[row][col];
    }

    @Override
    public void setPiece(int row, int col, PieceColour piece) {
        checkValid(row,col);
        //FIXME: this is interesting, but seems no way to implement an invalid pieceColour
        if (piece!=WHITE&&piece!=BLACK&&piece!=NONE){
            throw new IllegalArgumentException("PieceColour is not valid");
        }
        grid[row][col] = piece;
    }

    @Override
    public Grid copy() {
        Grid copyGrid = new GridImpl(size);
        for (int i = 0; i < size;i++){
            for (int j = 0 ; j < size;j++){
                //use of deep copy, properties do not share same reference.
                copyGrid.setPiece(i,j,this.getPiece(i,j));
            }
        }
        return copyGrid;
    }

    /**
     * To check if the grid is valid (not out of bounds)
     * @param row row of the grid
     * @param col column of the grid
     */
    public void checkValid(int row, int col){
        if (row < 0 || row >= size || col < 0 || col >= size){
            throw new IllegalArgumentException("Row or Column is invalid");
        }
    }

    /**
     * StringBuilder is a good way to implement toString method, don't know if this
     * causes my marks are deducted in the assessed lab
     * @return Grid representation in String type
     */
    public String toString(){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++){
            for (int j = 0; j < size; j++){
                sb.append(transform(grid[i][j]));
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    // transform the PieceColour to String
    public String transform(PieceColour p){
        if (p.equals(BLACK)){
            return "B";
        }
        else if (p.equals(WHITE)){
            return "W";
        }
        return ".";
    }

    public static void main(String[] args) {
        Grid grid1 = new GridImpl(3);
        grid1.setPiece(2,1,null);
        System.out.println(grid1.getPiece(2,1));
    }
}
